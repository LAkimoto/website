var ody=document.getElementById('ydmc');
if (yaudio.paused) {
ody.className = 'iconfont icon-bofang';
} else {
ody.className = 'iconfont icon-music';
}