<?php
//
//第三方分享组件 傻瓜式判断条件显示
//
 if($this->options->Share == '1'){ if($this->options->Shares[0] !== null){echo $this->options->Shares[0];}if($this->options->Shares[1] !== null){echo ','.$this->options->Shares[1];}if($this->options->Shares[2] !== null){echo ','.$this->options->Shares[2];}if($this->options->Shares[7] !== null){echo ','.$this->options->Shares[7];}if($this->options->Shares[3] !== null){echo ','.$this->options->Shares[3];}if($this->options->Shares[4] !== null){echo ','.$this->options->Shares[4];}if($this->options->Shares[5] !== null){echo ','.$this->options->Shares[5];}if($this->options->Shares[6] !== null){echo ','.$this->options->Shares[6];}} 
?>
